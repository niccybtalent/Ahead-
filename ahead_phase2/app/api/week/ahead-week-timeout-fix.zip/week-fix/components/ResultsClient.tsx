"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import type { AssessmentAnswers, GeneratedPlan, WeekDetail } from "@/lib/types";
import { createClient } from "@/lib/supabase/client";
import WeekDetailPanel from "@/components/WeekDetailPanel";

const WEEK_CACHE_KEY = "aheadWeekDetails";

export default function ResultsClient() {
  const [plan, setPlan] = useState<GeneratedPlan | null>(null);
  const [assessment, setAssessment] = useState<AssessmentAnswers | null>(null);
  const [saveState, setSaveState] = useState("");
  const [openWeek, setOpenWeek] = useState<number | null>(null);
  const [weeks, setWeeks] = useState<Record<number, WeekDetail>>({});
  const [weekBusy, setWeekBusy] = useState<number | null>(null);
  const [weekStage, setWeekStage] = useState("");
  const [weekError, setWeekError] = useState<Record<number, string>>({});

  useEffect(() => {
    try {
      const storedPlan = localStorage.getItem("aheadGeneratedPlan");
      const storedAssessment = localStorage.getItem("aheadAssessment");
      if (storedPlan) setPlan(JSON.parse(storedPlan));
      if (storedAssessment) setAssessment(JSON.parse(storedAssessment));
      const storedWeeks = localStorage.getItem(WEEK_CACHE_KEY);
      if (storedWeeks) setWeeks(JSON.parse(storedWeeks));
    } catch {}
  }, []);

  async function openWeekDetail(weekNumber: number) {
    if (openWeek === weekNumber) {
      setOpenWeek(null);
      return;
    }
    setOpenWeek(weekNumber);
    if (weeks[weekNumber] || weekBusy !== null) return;
    if (!plan || !assessment) return;

    setWeekBusy(weekNumber);
    setWeekError((prev) => ({ ...prev, [weekNumber]: "" }));

    // Read a response that may not be JSON (for example a platform timeout
    // page), so the real cause surfaces instead of a parse error.
    async function call<T>(url: string, payload: unknown, label: string): Promise<T> {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const body = await response.text();
      let parsed: T & { error?: string };
      try {
        parsed = JSON.parse(body);
      } catch {
        throw new Error(
          response.status === 504 || /timed? ?out/i.test(body)
            ? `${label} took too long. Please try this week again.`
            : `The server returned an unexpected response (${response.status}) while ${label.toLowerCase()}.`
        );
      }
      if (!response.ok) throw new Error(parsed.error || `We couldn’t finish ${label.toLowerCase()}.`);
      return parsed;
    }

    try {
      const base = {
        week_number: weekNumber,
        assessment,
        diagnosis: plan.diagnosis,
        curriculum: plan.curriculum,
      };

      // Split into two requests so neither half approaches the platform's
      // function timeout.
      setWeekStage("Searching for current resources…");
      const research = await call<{ notes: string; verified: Array<{ url: string; title: string }> }>(
        "/api/week/research",
        base,
        "The resource search"
      );

      setWeekStage("Shaping your sessions…");
      const detail = await call<WeekDetail>(
        "/api/week",
        { ...base, notes: research.notes, verified: research.verified },
        "Building the week"
      );

      const next = { ...weeks, [weekNumber]: detail };
      setWeeks(next);
      try {
        localStorage.setItem(WEEK_CACHE_KEY, JSON.stringify(next));
      } catch {}
    } catch (error) {
      setWeekError((prev) => ({
        ...prev,
        [weekNumber]: error instanceof Error ? error.message : "Something went wrong.",
      }));
    } finally {
      setWeekBusy(null);
      setWeekStage("");
    }
  }

  async function savePlan() {
    if (!plan || !assessment) return;
    setSaveState("Saving…");
    try {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        window.location.href = "/login?next=/results";
        return;
      }

      const { data: assessmentRow, error: assessmentError } = await supabase.from("assessments").insert({ user_id: user.id, answers: assessment }).select("id").single();
      if (assessmentError) throw assessmentError;

      const { data: diagnosisRow, error: diagnosisError } = await supabase.from("diagnoses").insert({
        user_id: user.id,
        assessment_id: assessmentRow.id,
        diagnosis: plan.diagnosis,
        model: plan.meta.model,
        prompt_version: plan.meta.diagnosis_prompt_version,
      }).select("id").single();
      if (diagnosisError) throw diagnosisError;

      const { error: programmeError } = await supabase.from("programmes").insert({
        user_id: user.id,
        diagnosis_id: diagnosisRow.id,
        programme: plan.curriculum,
        model: plan.meta.model,
        prompt_version: plan.meta.curriculum_prompt_version,
      });
      if (programmeError) throw programmeError;

      setSaveState("Saved ✓");
    } catch (error) {
      setSaveState(error instanceof Error ? error.message : "Couldn’t save your plan.");
    }
  }

  if (!plan) {
    return (
      <main className="assessment-wrap narrow">
        <section className="question-card">
          <h1>No plan here yet.</h1>
          <p className="lead">Complete the Ahead assessment first and we’ll build it.</p>
          <Link className="primary-btn button-link" href="/assessment">Start assessment →</Link>
        </section>
      </main>
    );
  }

  const { diagnosis, curriculum } = plan;
  const strengths = diagnosis.strengths.slice(0, 4);
  const priorityRank = { high: 0, medium: 1, low: 2 } as const;
  const gaps = [...diagnosis.capability_gaps]
    .sort((a, b) => priorityRank[a.priority] - priorityRank[b.priority])
    .slice(0, 4);
  const deprioritise = diagnosis.deprioritise.slice(0, 4);

  return (
    <main className="result-wrap">
      <section className="result-hero">
        <div className="eyebrow">✦ Your Ahead diagnosis</div>
        <h1>This is what actually matters next.</h1>
        <p>Your plan was generated from your assessment using Ahead’s diagnosis → curriculum architecture.</p>
      </section>

      <div className="now-next">
        <div className="state-card"><div className="label">Today</div><div className="big">{diagnosis.current_profile.summary}</div></div>
        <div className="state-arrow">→</div>
        <div className="state-card"><div className="label">Where you’re heading</div><div className="big">{diagnosis.target_profile.summary}</div></div>
      </div>

      <div className="insight-grid">
        <div className="insight-card"><strong>Your advantage</strong><ul>{strengths.map((x) => <li key={x.name}>{x.name}</li>)}</ul></div>
        <div className="insight-card"><strong>Biggest gaps</strong><ul>{gaps.map((x) => <li key={x.capability}>{x.capability}</li>)}</ul></div>
        <div className="insight-card"><strong>Useful depth</strong><ul><li>{diagnosis.current_profile.ai_maturity}</li><li>{diagnosis.current_profile.builder_maturity}</li><li>{diagnosis.target_profile.responsibility_shift}</li></ul></div>
        <div className="insight-card"><strong>Don’t waste time on</strong><ul>{deprioritise.map((x) => <li key={x.skill}>{x.skill}</li>)}</ul></div>
      </div>

      <div className="think-box">
        <h2>What we think</h2>
        <p>{diagnosis.development_strategy}</p>
      </div>

      <section className="roadmap">
        <div className="roadmap-head">
          <div><div className="eyebrow">{curriculum.programme_title}</div><h2>Your 10 weeks Ahead</h2><p className="roadmap-intro">{curriculum.programme_strategy}</p></div>
          <button className="secondary-btn" onClick={savePlan}>{saveState || "Save my plan"}</button>
        </div>
        <div className="week-list">
          {curriculum.weeks.map((week) => {
            const isOpen = openWeek === week.week_number;
            const detail = weeks[week.week_number];
            const busy = weekBusy === week.week_number;
            const error = weekError[week.week_number];
            return (
              <div className={`week-block ${isOpen ? "open" : ""}`} key={week.week_number}>
                <button
                  className="week-card week-trigger"
                  onClick={() => openWeekDetail(week.week_number)}
                  aria-expanded={isOpen}
                >
                  <div className="week-num">{String(week.week_number).padStart(2, "0")}</div>
                  <div>
                    <h3>{week.title}</h3>
                    <p>{week.why_this_matters_for_you}</p>
                  </div>
                  <div className="week-output">
                    <strong>You’ll finish with</strong>
                    {week.output}
                    <span className="week-toggle">
                      {busy ? "Building…" : detail ? (isOpen ? "Hide week ↑" : "Open week ↓") : "Build this week ↓"}
                    </span>
                  </div>
                </button>

                {isOpen && (
                  <div className="week-panel">
                    {busy && (
                      <div className="week-loading">
                        <div className="loading-orb small" />
                        <div>
                          <strong>Building week {week.week_number}.</strong>
                          <p>{weekStage || "Searching for current resources, then shaping your sessions."} This takes a minute or two.</p>
                        </div>
                      </div>
                    )}
                    {error && <div className="error-box">{error}</div>}
                    {detail && <WeekDetailPanel detail={detail} />}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <div className="cta-row centre-row">
          <button className="primary-btn" onClick={() => openWeekDetail(1)}>
            {weeks[1] ? "Open Week 1 →" : "Start Week 1 →"}
          </button>
        </div>
        <div className="footer-note">Generated with {plan.meta.model} · {plan.meta.diagnosis_prompt_version} · {plan.meta.curriculum_prompt_version}</div>
      </section>
    </main>
  );
}
